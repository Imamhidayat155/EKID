
                <section class="content">
                    <!-- Main page content-->
                        <center>
                            <!-- Custom page header alternative example-->
                            <div class="d-flex justify-content-between align-items-sm-center flex-column flex-sm-row mb-4">
                                <div class="me-4 mb-3 mb-sm-0">
                                    <!-- <h1 class="mb-0">Pengumuman</h1> -->
                                    <div class="small">
                                        <span class="fw-500 text-primary"><?=date("l",time())?></span>
                                        &middot; <?=date('F d, Y')?>
                                    </div>
                                </div>
                                <!-- Date range picker example-->
                                <div class="input-group input-group-joined border-0 shadow" style="width: 16.5rem">
                                    <span class="input-group-text"><i data-feather="calendar"></i></span>
                                    <!-- <input class="form-control ps-0 pointer" id="litepickerRangePlugin" placeholder="Select date range..." /> -->
                                </div>
                            </div>

                            <!-- Illustration dashboard card example-->
                            <div class="row justify-content-center">
                                <div class="card-body col-12">
                                    <h1 class="text-primary">System E-Cuti Belum bisa Dipakai</h1>
                                    <h2 class="text-primary">Sedang Proses Closing Cuti 2021.</h2>
                                    <img class="img-fluid" src="<?php echo base_url()?>assets/assets_new/images/under_dev.gif" style="width: 50%"/>
                                </div>
                            </div>
                        </center>

                </section>